# Unity-Platformer-Episode-12
In this episode we'll add the following features to our 2D platformer: controllable jump height, coyote time, double jumping (triple jumping etc.) and finally fix the wall jumping.
https://www.youtube.com/watch?v=oFO4pgrQPOI&ab_channel=Pandemonium
